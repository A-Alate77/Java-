package com.core;

public enum plan {
	MONTHLY(3000),QUARTERLY(11700),HALFYEAR(17500),YEARLY(32000);
	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	private plan(int amount) {
		this.amount = amount;
	}

	private int amount;


}
