package com.core;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.Period;

public class Customer implements Serializable
{
	private  int Customerid;
	
	private String firstname;
	private String Lastname;
	private String email;
	private String password;
	private String Address;
	private LocalDate registrationdate ;
	private LocalDate enddate;
	private String phoneno;
	private plan planame;
	private double amount;
	private static int custid;
	
	static {
		custid=100;
	}
	public Customer( String firstname, String lastname, String email, String password, String address,
			LocalDate date, String phoneno, plan planame, double amount) {
		super();
	     this.Customerid=custid; 
		this.firstname = firstname;
		Lastname = lastname;
		this.email = email;
		this.password = password;
		Address = address;
		this.registrationdate = date;
		this.phoneno = phoneno;
		this.planame = planame;
		this.amount = amount;
		if(planame==plan.MONTHLY)
		this.enddate=registrationdate.plusMonths(1);
		if(planame==plan.QUARTERLY)
			this.enddate=registrationdate.plusMonths(3);
		if(planame==plan.HALFYEAR)
			this.enddate=registrationdate.plusMonths(6);
		if(planame==plan.YEARLY)
			this.enddate=registrationdate.plusMonths(12);
		custid++;
	}
	
	public Customer(String email) {
		super();
		this.email = email;
	}

	@Override
	public String toString() {
		return "Customer [Customerid=" + Customerid + ", firstname=" + firstname + ", Lastname=" + Lastname + ", email="
				+ email + ", password=" + password + ", Address=" + Address + ", date=" + registrationdate + ", phoneno=" + phoneno
				+ ", planame=" + planame + ", amount=" + amount + "]";
	}
	public int getCustomerid() {
		return Customerid;
	}
	public void setCustomerid(int customerid) {
		Customerid = customerid;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return Lastname;
	}
	public void setLastname(String lastname) {
		Lastname = lastname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public LocalDate getDate() {
		return registrationdate;
	}
	public void setDate(LocalDate date) {
		this.registrationdate = date;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	public plan getPlaname() {
		return planame;
	}
	public void setPlaname(plan planame) {
		this.planame = planame;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public boolean equals(Object obj) 
	{
		if(obj instanceof Customer)
	  return this.getEmail().equals(((Customer) obj).getEmail());
		else
			return false;
		
	}
	

}
