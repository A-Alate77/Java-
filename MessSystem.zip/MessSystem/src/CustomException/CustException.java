package CustomException;

public class CustException extends Exception {
	
	
	public CustException(String msg)
	{
		super(msg);
	}

}
