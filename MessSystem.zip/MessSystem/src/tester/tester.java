package tester;

import java.time.Period;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

import com.core.Customer;
import com.core.plan;

import utils.binarycust;
import utils.checkemail;
import utils.populatelist;
import validate.validatecustomer;
import static validate.validatecustomer.*;
public class tester {
	
	public static void main(String[] args) 
	{
		 
//		List<Customer> clist=new ArrayList<>();
//		clist=populatelist.populateCustomer();
		List<Customer> clist=new ArrayList<>();
		clist=binarycust.decodebinary("kedar1.ser");
		System.out.println("---welcome to the customer management system---");
		
			boolean exit=true;
			try(Scanner sc=new Scanner(System.in))
			{
			while(exit)
			{
				try
				{
				System.out.println("Enter the choice 0.Exit 1.sign up 2.display 3.Sign in 4.Reset password 5.Sorting operations \n 6.unsubscribe customer 7.modify cutomer name 8.Display email addresses of the customers who did registration in month of January \n 9.Display count of the Customers who have register for plan: Monthly\n 10.Customer who lives in Akurdi \n 11.//Give the 20% discount to the customers who have selected plan for 1 year.");
				switch(sc.nextInt())
				{
				case 1: 
				      System.out.println("/ customerid,  firstname,  lastname,  email,  password,  address,\r\n"
				      		+ "// date,  phoneno,  planame,  amount");
				      Customer c=validateall(sc.next(),sc.next(),sc.next(),sc.next(),sc.next(),sc.next(),sc.next(),sc.next(),sc.nextDouble(),clist);
				      clist.add(c);
				      System.out.println("new profile has been created...");
					break;
				case 2:
					System.out.println("Displaying list...");
					clist.stream().forEach( System.out::println);
					break;
				case 3: 
					System.out.println("Enter the email and password for sign in...");
					Customer c1=checkemail.findbyemail(sc.next(),clist);
					String pass=sc.next();
					 
					if(c1.getPassword().equals(pass))
						System.out.println("login sucessful...");
					else
						System.out.println("login unsucessful...");
					break;
				case 4 :
					System.out.println("enter the email old password");
					System.out.println("Enter the email and password for sign in...");
					Customer c4=checkemail.findbyemail(sc.next(),clist);
					String pass2=sc.next();
					 
					if(c4.getPassword().equals(pass2))
					
					{	
						System.out.println("login sucessful...");
						System.out.println("enter the new password..");
						String newpass=sc.next();
						c4.setPassword(newpass);
					}
					
					break;
				case 5:
				
					System.out.println("Sorting by firstame");
					clist.stream().sorted((e1,e2)-> e1.getFirstname().compareTo(e2.getFirstname())).forEach(System.out::println);
					System.out.println("sorting by plan");
					clist.stream().sorted((e1,e2)-> e1.getPlaname().compareTo(e1.getPlaname())).forEach(System.out::println);
					clist.stream().sorted(Comparator.comparing(Customer::getPlaname)).forEach(System.out::println);
					System.out.println("sorting by registrationdate");
					clist.stream().sorted((o1,o2)-> o1.getDate().compareTo(o2.getDate())).forEach(System.out::println);
					break;
				case 6://Unsubscribe customer according plan duration (month wise (1, 3, 6, 12))
					 List<Customer> plist= new ArrayList<Customer>();
					 System.out.println("enter the plan duration");
					 int dur=sc.nextInt();
					 if(dur==1)
				      {plist=clist.stream().filter(s->s.getPlaname()==plan.MONTHLY).collect(Collectors.toList());
				   clist.removeAll(plist);
				      }
					 else if(dur==3)
					 { plist=clist.stream().filter(s->s.getPlaname()==plan.QUARTERLY).collect(Collectors.toList());
					   clist.removeAll(plist);
					 }
					 else if(dur==6)
					 { plist=clist.stream().filter(s->s.getPlaname()==plan.HALFYEAR).collect(Collectors.toList());
					   clist.removeAll(plist);
					 }
					 else if(dur==3)
					 { plist=clist.stream().filter(s->s.getPlaname()==plan.YEARLY).collect(Collectors.toList());
					   clist.removeAll(plist);
					 }
					break;
				case 7://) Modify all customers first name (make first Letter capital of customers first name)
					Iterator<Customer> itr=clist.iterator();
					while(itr.hasNext())
					{
						itr.next().setFirstname(itr.next().getFirstname().replaceFirst("^.",itr.next().getFirstname().toUpperCase()));
					}
					break;
				case 8://Display email addresses of the customers who did registration in month of January
					
					clist.stream().filter(s->s.getDate().getMonthValue()==1).forEach(System.out::println);
				
				break;
				case 9://Display count of the Customers who have register for plan: Monthly
					long i=clist.stream().filter(s->s.getPlaname()==plan.MONTHLY).count();
				    System.out.println(i);
					break;
				case 10:
					clist.stream().filter(s->s.getAddress().equals("Akurdi")).forEach(s->System.out.println(s));
					break;
				case 11://Give the 20% discount to the customers who have selected plan for 1 year.
					Iterator<Customer> itr2=clist.iterator();
					while(itr2.hasNext())
					{
						Customer c11=itr2.next();
						if(c11.getPlaname().equals(plan.YEARLY))
						{
							c11.setAmount(c11.getAmount()*0.80);
						System.out.println(c11);
						}
						
					}
					break;
				case 12: 
					binarycust.encodebinary(clist,"kedar1.ser");
					System.out.println("file has been saved");
					break;
				
				case 0: 
					
					exit=false;
					break;
					
				}	
				}catch (Exception e)
				{
					sc.nextLine();
					System.out.println(e.getMessage());
				}
			}
			
			}	
		}
}

//int customerid, String firstname, String lastname, String email, String password, String address,
//LocalDate date, String phoneno, plan planame, double amount