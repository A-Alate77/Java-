package utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import com.core.Customer;

public interface binarycust 
{
	static void encodebinary(List<Customer> clist, String filename) throws FileNotFoundException, IOException
	{
		try(ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream(filename)))
		{
			out.writeObject(clist);
		}
	}
	
	static List<Customer> decodebinary(String filename)
	{
		try(ObjectInputStream in=new ObjectInputStream(new FileInputStream(filename)))
		{
			List<Customer> clist=new ArrayList<>();
			clist=(List<Customer>) in.readObject();
			return clist;
			
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
			return new ArrayList<>();
		} catch (IOException e) {
		
			e.printStackTrace();
			return new ArrayList<>();
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
			return new ArrayList<>();
		}

		
	}

}
