package utils;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.core.Customer;
import com.core.plan;
//String firstname, String lastname, String email, String password, String address,
//LocalDate date, String phoneno, plan planame, double amount
public class populatelist 
{
	public static List<Customer> populateCustomer(){
		/*String firstName, String lastName, String email, String password, String address,
			LocalDate regDate, String phoneNo, Plan plan, double final_amount*/
		List<Customer> lst=new ArrayList<Customer>(Arrays.asList(
				new Customer("kedar","kulkarni","kedarkulkarni@gmail.com","1234","pune",LocalDate.parse("2022-01-01"), "2143", plan.valueOf("MONTHLY"),1200),
				new Customer("amar","verma","amitverma@gmail.com","417","Akurdi",LocalDate.parse("2023-01-01"), "2143", plan.valueOf("HALFYEAR"),1200),
				new Customer("mahadev","sharma","mahadev123@gmail.com","425","pune",LocalDate.parse("2023-02-05"), "2143", plan.valueOf("MONTHLY"),1200),
				new Customer("shrushti","koli","shrushti477@gmail.com","45678","Akurdi",LocalDate.parse("2023-01-06"), "2143", plan.valueOf("YEARLY"),1200),
				new Customer("naveen","yadav","naveenyadav123@gmail.com","53698","pune",LocalDate.parse("2023-01-07"), "2143", plan.valueOf("QUARTERLY"),1200),
				new Customer("ravi","lahane","rvilahane@gmail.com","4253758","pune",LocalDate.parse("2023-01-08"), "2143", plan.valueOf("YEARLY"),1200)
				
				));
		
		return lst;
	}

}
