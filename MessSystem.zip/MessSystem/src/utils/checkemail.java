package utils;

import java.util.List;

import com.core.Customer;

import CustomException.CustException;

public class checkemail {
	
	public static Customer findbyemail(String email,List<Customer> clist) throws CustException
	{
		Customer c=new Customer(email);
		
		 int index=clist.indexOf(c);
		 if(index == -1)
			 throw new CustException("Invalid email. email not found...");
		    return clist.get(index);
		
	
	}
	

}
