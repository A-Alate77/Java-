package validate;

import java.text.ParseException;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import com.core.Customer;
import com.core.plan;

import CustomException.CustException;

public class validatecustomer 
{
	public static void checkmail(String email,List<Customer> clist) throws CustException
	{
		String s="[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}";
		if(!email.matches(s))
		throw new CustException("Invalid email...");
		Customer c=new Customer(email);
		if(clist.contains(c))
			throw new CustException("duplicate email found..");
		
	}
	
	public  static plan checkplan(String plans) throws IllegalArgumentException
	{
		plan p=plan.valueOf(plans.toUpperCase());
		return p;
	}
	
	public static LocalDate checkdate(String date) throws ParseException
    {
		LocalDate p=LocalDate.parse(date);
		return p;
	}
	
	public static void checkphone(String phoneno) throws CustException
	{
		String s="^\\d{10}$";
		if(!phoneno.matches(s))
		 throw new CustException("no acceptable phone no...");
		
	}
	
	
	public static Customer validateall( String firstname, String lastname, String email, String password, String address,
			String date, String phoneno, String planame, double amount,List<Customer> clist) throws CustException, ParseException
	{
		checkmail(email,clist);
		plan p=checkplan(planame);
		LocalDate d=checkdate(date);
		checkphone(phoneno);
		
		return new Customer(firstname,lastname,email,password,address,d,phoneno,p,amount);
		
	}

}




//int customerid, String firstname, String lastname, String email, String password, String address,
//LocalDate date, String phoneno, plan planame, double amount